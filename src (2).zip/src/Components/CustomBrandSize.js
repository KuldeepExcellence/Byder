import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const CustomBrandSize = () => {
  return (
    <View>
      <Text>CustomBrandSize</Text>
    </View>
  )
}

export default CustomBrandSize

const styles = StyleSheet.create({})