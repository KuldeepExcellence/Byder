
// export const Baseurl='http://138.68.95.163:8000'
export const Baseurl='https://byder-backend-3l2yk.ondigitalocean.app'

