import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const CustomBrand = () => {
  return (
    <View>
      <Text>CustomBrand</Text>
    </View>
  )
}

export default CustomBrand

const styles = StyleSheet.create({})