import { StyleSheet, Text, View, StatusBar, ScrollView, Image, TextInput } from 'react-native'
import React from 'react'
import Topbarback from '../../Components/Topbarback'
import { widthPercentageToDP as wp, heightPercentageToDP as hp } from 'react-native-responsive-screen';
import { MainBlack, White } from '../../Components/ColorConst/ColorConst';
const SubirTicket = ({ navigation }) => {
  const [text, onChangeText] = React.useState('Useless Text');
  const [number, onChangeNumber] = React.useState('');
  return (
    <>
      <StatusBar backgroundColor={'#000'} />
      <Topbarback Textheading={'Subir ticket'} navigation={navigation} />
      <View style={styles.main2}>
        <Text style={styles.subti}>Subir ticket</Text>

        <View style={styles.searcmain}>
          <View style={styles.srchmainim}>
            <View>
              <Image style={styles.srchim} source={require('../../Assets/camera.png')} tintColor='#959596' />
            </View>
            <Text style={styles.input} > Choose an Image</Text>
          </View>
        </View>

        {/* <View style={styles.hrline} /> */}
      </View>
    </>
  )
}
export default SubirTicket
const styles = StyleSheet.create({
  main2: {
    flex: 1,
    backgroundColor: '#15181e',
    padding: 10,
    // height: hp('124%'),
  },
  subti: {
    color: '#727375',
    fontSize: hp('1.9%'),
    fontWeight: '600',
    marginLeft: hp('0.6%'),
  },
  searcmain: {
    height: hp('6%'),
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#272a30',
    width: wp('93%'),
    marginTop: hp('0.6%'),
    marginLeft: hp('0.6%'),
    borderRadius: 10,
  },
  srchmainim: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    justifyContent: 'center',
  },

  srchim: {
    height: hp('2.5%'),
    width: wp('5.2%'),
    marginTop: hp('1.2%'),
    marginLeft: hp('1%'),
  },
  input: {
    color: '#959596',
    height: 40,
    width: wp('84%'),
    // borderWidth: 1,
    // padding: 8,
    // paddingLeft: 18,
    marginLeft: hp('-2.4%'),
    borderRadius: 10,
    alignSelf: 'center',
    marginTop: hp('0.6%'),
    border: 'none',
  },
  hrline: {
    height: hp('0.2%'),
    width: wp('92%'),
    backgroundColor: '#333333',
    marginTop: hp('-2%'),
    alignSelf: 'center',
  },
})