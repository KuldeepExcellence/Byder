import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const SignOut = () => {
  return (
    <View>
      <Text>SignOut</Text>
    </View>
  )
}

export default SignOut

const styles = StyleSheet.create({})