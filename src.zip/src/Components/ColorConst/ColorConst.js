export const LightYellow='#DAFDA5';
export const MainBlack='#000';
export const White='#fff';
export const Black='#000';
export const sidebarBlack='#182026'
