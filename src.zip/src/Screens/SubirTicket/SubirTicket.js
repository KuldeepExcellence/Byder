import { StyleSheet, Text, View ,StatusBar,ScrollView,Image ,TextInput} from 'react-native'
import React from 'react'
import Topbarback from '../../Components/Topbarback'
import { widthPercentageToDP as wp, heightPercentageToDP as hp } from 'react-native-responsive-screen';
import {  MainBlack, White } from '../../Components/ColorConst/ColorConst';
const SubirTicket = ({navigation}) => {
    const [text, onChangeText] = React.useState('Useless Text');
    const [number, onChangeNumber] = React.useState('');
  return (
    <>
         <StatusBar backgroundColor={'#000'} />
            <Topbarback Textheading={'Subir ticket'} navigation={navigation} />
                <View style={styles.main2}>
                       <Text style={styles.subti}>Subir ticket</Text>
                       <View style={styles.searcmain}>
        <View style={styles.srchmainim}>
            <View style={styles.serchm}>
              <Image style={styles.srchim} source={require('../../Assets/camera.png')} />
              </View>
    <TextInput
        style={styles.input}
        onChangeText={onChangeNumber}
        value={number}
        placeholder="  Choose an image..."
        placeholderTextColor={'#737373'}
      />
      </View>
    </View>
    <View style={styles.hrline} />
                    </View>
    </>
  )
}
export default SubirTicket
const styles = StyleSheet.create({
    main2: {
        flex: 1,
        backgroundColor: '#221D28',
        padding: 10,
        // height: hp('124%'),
    },
    subti:{
        color: '#8C8C8C',
        fontSize: hp('2.1%'),
    },
    searcmain:{
        height:hp('10%'),
      },
      srchmainim:{
        flexDirection:'row',
    },
    serchm:{
        height: 40,
        backgroundColor:'#333333',
        width:wp('12%'),
        marginTop: hp('0.6%'),
        marginLeft:hp('0.6%'),
        borderRadius:10,
    },
    srchim:{
        height: hp('2.5%'),
        width: wp('5.2%'),
        marginTop: hp('1.2%'),
        marginLeft:hp('1%'),
    },
    input: {
        backgroundColor:'#333333',
        height: 40,
        width:wp('84%'),
        // borderWidth: 1,
        // padding: 8,
        // paddingLeft: 18,
        marginLeft:hp('-2.4%'),
        borderRadius:10,
        alignSelf:'center',
        marginTop:hp('0.6%'),
   border:'none',
      },
      hrline: {
        height: hp('0.2%'),
        width: wp('92%'),
        backgroundColor: '#333333',
        marginTop: hp('-2%'),
        alignSelf: 'center',
    },
})