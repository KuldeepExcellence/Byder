import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const MyOrderReseve = () => {
  return (
    <View>
      <Text>MyOrderReseve</Text>
    </View>
  )
}

export default MyOrderReseve

const styles = StyleSheet.create({})